# 白鹭引擎 5.2.13 发布日志


---


白鹭引擎在 2018年5月25日 正式发布了 5.2 稳定版本。在 2018年11月27日，我们将发布 5.2.13 稳定版本。本次版本加入了对百度小游戏的支持


## 2D 渲染 - JavaScript 

* 修复开启原生显示列表情况下 eui.Image 设置填充模式失效问题

## 百度小游戏

* 新增百度小游戏支持，文档点击[这里](http://developer.egret.com/cn/github/egret-docs/Engine2D/minigamebaidu/index.html)