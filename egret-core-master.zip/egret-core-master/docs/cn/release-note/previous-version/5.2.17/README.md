# 白鹭引擎 5.2.17 发布日志


---


白鹭引擎在 2018年5月25日 正式发布了 5.2 稳定版本。在 2019年4月1日，我们将发布 5.2.17 稳定版本。

## 2D 渲染 - JavaScript 
* 修复 `egret.Timer` 不会抛出 `Timer` 事件的问题
* 优化 `egret.registerClass` 方法，兼容百度小游戏 `iOS` 版本

## 微信小游戏 v1.1.12
* 修复 `WebHttpRequest` 读取本地数据时，`responseType` 设置为 `json` 时，返回的是字符串的问题
