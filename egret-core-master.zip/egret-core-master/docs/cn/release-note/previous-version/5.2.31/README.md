# 白鹭引擎 5.2.31 发布日志
白鹭引擎在 2019年11月14日，发布 5.2.31 稳定版本。

- **[新增]** [支持微信引擎插件功能](http://developer.egret.com/cn/github/egret-docs/Engine2D/minigame/useWxPlugin/index.html)
