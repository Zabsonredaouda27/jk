# Egret Engine 5.2.20 Release Notes

---

On May 28, 2019, Egret Engine will release a stable version of 5.2.20.

## 2D Rendering - JavaScript
- **[new]** Support `KTX` format for storing textures.

## WeChat Game v1.1.13
- **[new]** Support `KTX` format for storing textures.
