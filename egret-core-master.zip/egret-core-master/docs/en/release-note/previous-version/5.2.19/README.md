# Egret Engine 5.2.19 Release Notes


---

On May 13, 2019, Egret Engine will release a stable version of 5.2.19.

## 2D Rendering - JavaScript
- **[new]** Support for publishing for OPPO minigame
- **[fix]** Images of WeChat games may have memory leaks
- **[fix]** URLLoader cannot load resources on some platforms
