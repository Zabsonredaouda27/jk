# Egret Engine 5.2.32 Release Notes
The Egret Engine released the 5.2.32 stable version on December 19, 2019.

- **[NEW]** [Support for QQGame engine plugin](https://github.com/egret-labs/egret-docs/tree/master/Engine2D/minigameqq/usePlugin)

## QQ Game v0.1.7
- **[FIX]**  When the sound is played for the first time, it will be played 2 times
- **[FIX]**  Fix an issue that gets user path misspelled

## Xiaomi QGame v0.2.12
- **[NEW]**  Support for subcontracting loading

## OPPO Game v0.2.9
- **[FIX]**  Fixed the problem of resource cache module error during sub-package loading

## vivo Game v0.2.13
- **[NEW]**  Support accelerometer
