# Egret Engine 5.2.25 Release Notes
The Egret Engine released the 5.2.25 stable version on July 30, 2019.

## 2D Rendering - JavaScript 
- **[new]** Support for publishing as QQ minigame
- **[fix]** Fix `ktx` in and filter mix ingress display errors

## vivo Game v0.2.4
- **[fix]** Fix an audio file loading error while the resource is cached
