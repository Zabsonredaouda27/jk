# Egret Engine 5.2.12 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On October 29, 2018, we will release a stable version of 5.2.12. This release is a centralized bug fix for version 5.2


## AssetsManager

* Fix RES.destroyRes will destroy all resource bugs when force parameter is false
* Fixing the destruction of unloaded groups will cause anomalies
* Fixed a failure in the group after the font image failed to load
* After fixing the texture set image failed, the group's failure event will not be answered