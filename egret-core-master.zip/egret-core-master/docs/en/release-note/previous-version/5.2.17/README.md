# Egret Engine 5.2.17 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On April 1, 2019, we will release a stable version of 5.2.17.


## 2D Rendering - JavaScript
* Fix the problem of `egret.Timer` does not throw `Timer` event.
* Optimization method `egret.registerClass`, compatible with BaiDu mini game

## WeChat Game v1.1.11
* Fix the problem, when the `responseType` is set to `json`, When the `WebHttpRequest` reads local data, return string value
